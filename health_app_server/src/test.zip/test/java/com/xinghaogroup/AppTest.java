package com.xinghaogroup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import com.xinghaogroup.health_app_server.HealthAppServerApplication;

@SpringBootTest(classes = HealthAppServerApplication.class)
public class AppTest {

    @Test
    public void testApp() {
        // 这里可以添加具体的测试逻辑
    }
}