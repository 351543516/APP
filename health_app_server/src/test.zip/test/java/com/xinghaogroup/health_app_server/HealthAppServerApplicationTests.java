package com.xinghaogroup.health_app_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest // 无需显式指定 classes，自动关联主类
class HealthAppServerApplicationTests {

	@Test
	void contextLoads() {
		// 测试方法保持空即可，仅验证上下文加载
	}
}